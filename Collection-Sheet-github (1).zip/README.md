# Collection Desk – Cartrend Auto Parts

Customer ageing aur payment follow-up tracker (TEJ ERP exports se).

**Live:** https://ronaksales-netizen.github.io/Collection-Sheet/

## Roz ka use
1. TEJ se 3 sheets export karein: `PrintAccountBalance`, `SalesReport` (hamesha Aug 2024 se), `PDC`.
2. Site par **Data upload karein** → teeno files daalein → **Process karke save karein**.
3. Upar ki patti mein dekhein: payment kitna aaya, naye customers, clear hue.
4. **Aaj ke follow-up** card kholein aur **Save karke agla customer** se calls update karein.

## Data kahan save hota hai
Saara data sirf us browser ke localStorage mein rehta hai jahan site kholi gayi hai.
Customer data is repo mein ya kisi server par nahi jaata. Hafte mein ek baar
**Backup** download karein; doosre computer par **Restore** se data wapas aa jayega.

> Is repo mein kabhi bhi TEJ ki CSV/Excel files commit na karein – repo public hai.
